package service;

public class CategoriaService {

}
